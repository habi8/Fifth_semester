public class ProxyImage implements Image {
    private String filename;
    private HighResolutionImage highResolutionImage;

    public ProxyImage(String filename) {
        this.filename = filename;
    }

    @Override
    public void display() {
        if (highResolutionImage == null) {
            highResolutionImage = new HighResolutionImage(filename);
        }
        highResolutionImage.display();
    }

    public String getFilename() {
        return filename;
    }
}
