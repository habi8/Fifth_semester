import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create an array of ProxyImage objects
        ProxyImage[] images = {
                new ProxyImage("Photo1.jpg"),
                new ProxyImage("Photo2.jpg"),
                new ProxyImage("Photo3.jpg")
        };

        // Display available images
        System.out.println("Available images:");
        for (int i = 0; i < images.length; i++) {
            System.out.println((i + 1) + ". " + images[i].getFilename());
        }



            Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter the number of the image you want to load and display (or 0 to exit): ");
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();

                if (choice == 0) {
                    System.out.println("Exiting...");
                    break;
                } else if (choice >= 1 && choice <= images.length) {
                    images[choice - 1].display();
                } else {
                    System.out.println("Invalid choice. Please select a valid image number.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Clear the invalid input
            }
        }

    }
}