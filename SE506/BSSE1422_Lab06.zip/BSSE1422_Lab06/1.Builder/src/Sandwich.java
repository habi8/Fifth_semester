public class Sandwich {
    private String bread;
    private String filling;
    private String accompaniment;

    SandwichBuilder builder;
    Sandwich(String bread, String filling, String accompaniment) {
        this.bread = bread;
        this.filling = filling;
        this.accompaniment = accompaniment;

    }

    @Override
    public String toString() {
        return "Sandwich [Bread = " + bread + ", Filling = " + filling + ", Accompaniment = " + accompaniment + "]";
    }
}