import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SandwichBuilder builder = new SandwichBuilder();

        // Menu for Bread

                System.out.println("Choose your bread:");
                System.out.println("1. White Bread");
                System.out.println("2. Whole Wheat Bread");
                System.out.println("3. Multigrain Bread");
                System.out.println("4. Toasted Bread");
                System.out.print("Enter the number corresponding to your choice: ");
                int breadChoice = scanner.nextInt();
                switch (breadChoice) {
                    case 1 -> builder.withBread("White Bread");
                    case 2 -> builder.withBread("Whole Wheat Bread");
                    case 3 -> builder.withBread("Multigrain Bread");
                    case 4 -> builder.withBread("Toasted Bread");
                    default -> System.out.println("Invalid choice. No bread selected.");
                }

                // Menu for Filling
                System.out.println("\nChoose your filling:");
                System.out.println("1. Grilled Chicken");
                System.out.println("2. Fried Egg");
                System.out.println("3. Veggie Patty");
                System.out.println("4. Turkey");
                System.out.print("Enter the number corresponding to your choice: ");
                int fillingChoice = scanner.nextInt();
                switch (fillingChoice) {
                    case 1 -> builder.withFilling("Grilled Chicken");
                    case 2 -> builder.withFilling("Fried Egg");
                    case 3 -> builder.withFilling("Veggie Patty");
                    case 4 -> builder.withFilling("Turkey");
                    default -> System.out.println("Invalid choice. No filling selected.");
                }

                // Menu for Accompaniment
                System.out.println("\nChoose your accompaniment:");
                System.out.println("1. Cheese");
                System.out.println("2. Lettuce");
                System.out.println("3. Tomato Sauce");
                System.out.println("4. Hot Sauce");
                System.out.print("Enter the number corresponding to your choice: ");
                int accompanimentChoice = scanner.nextInt();
                switch (accompanimentChoice) {
                    case 1 -> builder.withAccompaniment("Cheese");
                    case 2 -> builder.withAccompaniment("Lettuce");
                    case 3 -> builder.withAccompaniment("Tomato Sauce");
                    case 4 -> builder.withAccompaniment("Hot Sauce");
                    default -> System.out.println("Invalid choice. No accompaniment selected.");
                }

                // Build the sandwich
                Sandwich sandwich = builder.build();
                System.out.println("\nYour customized sandwich:");
                System.out.println(sandwich);

                scanner.close();


    }
}