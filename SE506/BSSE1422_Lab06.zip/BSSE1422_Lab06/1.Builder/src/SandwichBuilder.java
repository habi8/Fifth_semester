public class SandwichBuilder {
    private String bread;
    private String filling;
    private String accompaniment;

    public SandwichBuilder withBread(String bread) {
        this.bread = bread;
        return this;
    }

    public SandwichBuilder withFilling(String filling) {
        this.filling = filling;
        return this;
    }

    public SandwichBuilder withAccompaniment(String accompaniment) {
        this.accompaniment = accompaniment;
        return this;
    }

    public Sandwich build() {
        return new Sandwich(bread,filling,accompaniment);
    }
}