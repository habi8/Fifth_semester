public interface FileSystem {
    boolean search(String name);
}
