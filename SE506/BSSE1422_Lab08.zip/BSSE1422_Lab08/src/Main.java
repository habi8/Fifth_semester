//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
            File file1 = new File("Document.pdf");
            File file2 = new File("Photo.jpg");
            File file3 = new File("Notes.pdf");

            Folder rootFolder = new Folder("RootFolder");
            Folder subFolder1 = new Folder("SubFolder1");
            Folder subFolder2 = new Folder("Subfolder2");

            subFolder1.add(file1);
            subFolder2.add(file2);
            subFolder2.add(file3);
            rootFolder.add(subFolder1);
            rootFolder.add(subFolder2);

            System.out.println("\nSearching for 'Doc': ");
            rootFolder.search("Doc");

            System.out.println("\nSearching for 'photo'");
            rootFolder.search("Photo");

            System.out.println("\nSearching for 'notes'");
            rootFolder.search("Notes");
    }
}