public class File implements FileSystem{
    private String name;

    public File(String name){
        this.name = name;
    }

    boolean found = false;
    public boolean search(String keyword){
        if(name.contains(keyword)){
            System.out.println("File \""+ name + "\"matches keyword" + keyword);
            return true;
        }
        else {
            System.out.println("File \"" + name + "\"does not match keyword" + keyword);
            return false;
        }

    }

    public String getName(){
        return name;
    }
}
