import java.util.ArrayList;
import java.util.List;
public class Folder implements FileSystem{
    private String name;
    private List<FileSystem> components = new ArrayList<>();

    public Folder(String name){
        this.name = name ;
    }

    public void add(FileSystem component){
        components.add(component);
    }

    public void remove(FileSystem component){
        components.remove(component);
    }

    public boolean search(String keyword){
        System.out.println("Searching in folder: " + name);
        boolean found ;
        for(FileSystem component: components){
           found= component.search(keyword);
            if(found)
                return true;
        }
        return false;
    }

    public String getName(){
        return name;
    }
}
