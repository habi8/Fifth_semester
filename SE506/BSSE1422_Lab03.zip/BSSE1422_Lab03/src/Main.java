//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

            public static void main(String[] args) {

                PrinterFactory printerFactory = PrinterFactory.getInstance();

                Printer IITPrinter = printerFactory.getPrinter("IIT");
                IITPrinter.printDocument("IIT Report");


                Printer ISRTPrinter = printerFactory.getPrinter("ISRT");
                ISRTPrinter.printDocument("ISRT Report");


                Printer anotherIITPrinter = printerFactory.getPrinter("IIT");
                anotherIITPrinter.printDocument("IIT attendance sheet");


            }

}