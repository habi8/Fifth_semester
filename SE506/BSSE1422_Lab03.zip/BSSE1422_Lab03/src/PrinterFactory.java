import java.util.HashMap;
import java.util.Map;

public class PrinterFactory {
    private Map<String, Printer> printerRegistry = new HashMap<>();

    private static PrinterFactory instance;

    private PrinterFactory() {}


    public static PrinterFactory getInstance() {
        if(instance == null) {
            synchronized (PrinterFactory.class){
                if (instance == null) {
                    instance = new PrinterFactory();
                }
            }
        }
        return instance;
    }

    public Printer getPrinter(String department) {
        if (!printerRegistry.containsKey(department)) {

            Printer printer = Printer.createPrinter(department);
            printerRegistry.put(department, printer);
        }
        else System.out.println("Same "+ department +" Printer returned below");
        return printerRegistry.get(department);
    }
}
