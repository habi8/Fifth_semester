public class Printer {
    private String department;

    private Printer(String department) {
        this.department = department;
    }

    public static Printer createPrinter(String department) {
        return new Printer(department);
    }

    public void printDocument(String document) {
        System.out.println("Printing document '" + document + "' from " + department + " department's printer.");
    }
}
