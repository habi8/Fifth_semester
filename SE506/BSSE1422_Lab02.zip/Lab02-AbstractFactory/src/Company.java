public interface Company {
    public abstract Chair createChair();
    public abstract Table createTable();
    public abstract Sofa createSofa();
}
