public interface Sofa {
    void workings();
}
