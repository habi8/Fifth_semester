public class RusticTable implements Table{
    @Override
    public void workings(){
        System.out.println("I'm a Rustic Table!");
    }
}
