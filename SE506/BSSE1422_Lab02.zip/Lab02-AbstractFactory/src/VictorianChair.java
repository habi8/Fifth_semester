public class VictorianChair implements Chair{
    @Override
    public void workings(){
        System.out.println("I'm a Victorian chair!");
    }
}
