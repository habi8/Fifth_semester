//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Company modern1 = new ModernFurniture();
        Chair modernChair = modern1.createChair();
        modernChair.workings();

        Company modern2 = new ModernFurniture();
        Table modernTable = modern2.createTable();
        modernTable.workings();

        Company modern3 = new ModernFurniture();
        Sofa modernSofa = modern3.createSofa();
        modernSofa.workings();
    }
}