public interface Table {
    void workings();
}
