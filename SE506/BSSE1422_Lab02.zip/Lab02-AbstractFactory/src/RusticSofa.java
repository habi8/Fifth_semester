public class RusticSofa implements Sofa{
    @Override
    public void workings(){
        System.out.println("I'm a Rustic Sofa!");
    }
}
