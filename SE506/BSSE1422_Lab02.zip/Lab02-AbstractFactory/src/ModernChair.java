public class ModernChair implements Chair{
    @Override
    public void workings(){
        System.out.println("I'm a Modern chair!");
    }
}
