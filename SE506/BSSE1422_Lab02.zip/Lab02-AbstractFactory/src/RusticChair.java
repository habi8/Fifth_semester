public class RusticChair implements Chair{
    @Override
    public void workings(){
        System.out.println("I'm a Rustic chair!");
    }
}
