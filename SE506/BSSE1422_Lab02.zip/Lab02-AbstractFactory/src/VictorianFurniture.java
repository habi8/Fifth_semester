public class VictorianFurniture implements Company{
    @Override
    public Chair createChair(){
        return new VictorianChair();
    }

    @Override
    public Table createTable(){
        return new VictorianTable();
    }

    @Override
    public Sofa createSofa(){
        return new VictorianSofa();
    }
}
