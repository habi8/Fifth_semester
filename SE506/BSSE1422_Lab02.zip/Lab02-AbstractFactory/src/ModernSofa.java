public class ModernSofa implements Sofa{
    @Override
    public void workings(){
        System.out.println("I'm a Modern Sofa!");
    }
}
