public interface Chair {
    void workings();
}
