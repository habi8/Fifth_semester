public class ModernTable implements Table{
    @Override
    public void workings(){
        System.out.println("I'm a Modern Table!");
    }
}
