public class VictorianSofa implements Sofa{
    @Override
    public void workings(){
        System.out.println("I'm a Victorian Sofa!");
    }
}
