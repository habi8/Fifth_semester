public class ModernFurniture implements Company{
    @Override
    public Chair createChair(){
        return new ModernChair();
    }

    @Override
    public Table createTable(){
        return new ModernTable();
    }

    @Override
    public Sofa createSofa(){
        return new ModernSofa();
    }
}
