public class VictorianTable implements Table{
    @Override
    public void workings(){
        System.out.println("I'm a Victorian Table!");
    }
}
