public interface Company {
    public  abstract Chair createChair();
}
