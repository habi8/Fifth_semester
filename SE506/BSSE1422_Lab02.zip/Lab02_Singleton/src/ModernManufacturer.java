public class ModernManufacturer implements Company{
    private static Chair instance ;

    public Chair createChair(){

       // if(instance == null) {
            synchronized (Company.class){
                if (instance == null) {
                    instance = new ModernChair();
                }
            }
       // }
        return instance;
    }
}
