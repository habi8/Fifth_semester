public interface Chair {
    public abstract void workings();
}
