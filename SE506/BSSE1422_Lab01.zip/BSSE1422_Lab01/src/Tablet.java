public class Tablet implements Software{
    String brand,model,year;
    Tablet(String brand,String model,String year){
        this.brand = brand;
        this.model = model;
        this.year = year;
    }
    @Override
    public String powerOn() {
        return "I am On";
    }
    public String powerOff() {
        return "I am Off";
    }

    public String toString(){
        return "brand is "+brand + " model is "+model + " release year" +year ;
    }

}
