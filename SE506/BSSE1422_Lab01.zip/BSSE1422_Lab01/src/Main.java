//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        SoftwareFactory MobileFactory = new MobileFactory();
        SoftwareFactory TabletFactory = new TabletFactory();
        SoftwareFactory LaptopFactory = new LaptopFactory();

        Software myMobile = MobileFactory.createSoftware("Iphone","Iphone 11","2019");
        Software myTablet = MobileFactory.createSoftware("Huwaei","MT 10","2011");
        Software myLaptop= MobileFactory.createSoftware("HP","Victus 3","2023");

        System.out.println(myMobile.toString());
        System.out.println(myMobile.powerOn());

        System.out.println(myTablet.toString());
        System.out.println(myMobile.powerOff());

        System.out.println(myLaptop.toString());
        System.out.println(myLaptop.powerOn());
    }
}