interface Software{
    String powerOn();
    String powerOff();
}
