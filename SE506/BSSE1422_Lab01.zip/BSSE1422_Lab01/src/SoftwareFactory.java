abstract class SoftwareFactory {
    abstract Software createSoftware(String brand,String model,String year);
}

class MobileFactory extends SoftwareFactory {
    @Override
    Software createSoftware(String brand,String model,String year){
        return new Mobile(brand,model,year);
    }
}

class TabletFactory extends SoftwareFactory {
    @Override
    Software createSoftware(String brand,String model,String year) {
        return new Tablet(brand,model,year);
    }
}
class LaptopFactory extends SoftwareFactory {
    @Override
    Software createSoftware(String brand,String model,String year) {
        return new Laptop(brand,model,year);
    }
}
