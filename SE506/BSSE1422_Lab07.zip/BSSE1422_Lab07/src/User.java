public class User {
    private String name;
    private int borrowedItems;
    private boolean hasPermission;

    public User(String name, int borrowedItems, boolean hasPermission){
        this.name = name;
        this.borrowedItems = borrowedItems;
        this.hasPermission = hasPermission;
    }

    public String getName(){
        return name;
    }

    public int getBorrowedItems(){
        return borrowedItems;
    }

    public void increaseItems(){
        borrowedItems++;
    }

    LibraryConfigManager configManager = LibraryConfigManager.getInstance();
    public boolean hasPermission(){
        if (borrowedItems<configManager.getBorrowingLimit()){
            return true;
        }

        else {
            return false;
        }

    }

    public void setPermission(boolean permission){
        this.hasPermission = permission;
    }
}
