public class RealLibraryAccess implements LibraryAccess{
    @Override
    public void accessItems(String ID,User user){
        System.out.println("Accessing item with ID "+ ID);
    }

}
