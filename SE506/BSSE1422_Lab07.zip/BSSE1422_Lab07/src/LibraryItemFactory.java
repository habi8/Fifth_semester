public class LibraryItemFactory {
    public static LibraryItems createLibraryItem(String type, String title) {
            if (type.equalsIgnoreCase("book")) {
                return new Book(title);
            } else if (type.equalsIgnoreCase("Magazine")) {
                return new Magazine(title);
            }

            throw new IllegalArgumentException("Unknown library item type");

    }
}

