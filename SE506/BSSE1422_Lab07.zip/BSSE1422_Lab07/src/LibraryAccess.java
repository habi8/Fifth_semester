public interface LibraryAccess {
    void accessItems(String itemID,User user);
}
