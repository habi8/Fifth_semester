public class Book implements LibraryItems{
    private String title;

    public Book(String title){
        this.title = title;
    }

    @Override
    public String getDetails(){
        return "book "+ title;
    }

    @Override
    public void borrowItems(){
        System.out.println("You have borrowed the book: "+ title);
    }
}
