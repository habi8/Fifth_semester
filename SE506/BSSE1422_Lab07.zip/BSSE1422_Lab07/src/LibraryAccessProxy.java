public class LibraryAccessProxy implements LibraryAccess{

    final RealLibraryAccess realLibraryAccess = new RealLibraryAccess();
    @Override
    public void accessItems(String itemID , User user){
        if(user.hasPermission()){
            realLibraryAccess.accessItems(itemID , user);
            user.increaseItems();
            if(user.getBorrowedItems()>=5)
                user.setPermission(false);
        }
        else System.out.println("Access denied for user: "+ user.getName());
    }
}
