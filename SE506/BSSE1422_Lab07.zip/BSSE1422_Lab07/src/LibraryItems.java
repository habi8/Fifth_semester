public interface LibraryItems {
    String getDetails();
    void borrowItems();
}
