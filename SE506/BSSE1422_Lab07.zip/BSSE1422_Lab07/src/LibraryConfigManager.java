public class LibraryConfigManager {
    private static LibraryConfigManager instance;
    private int lateFees;
    private int borrowingLimit;

    private LibraryConfigManager(){
        this.lateFees = 10;
        this.borrowingLimit = 5;
    }

    public static LibraryConfigManager getInstance(){
        if(instance == null){
            instance = new LibraryConfigManager();
            System.out.println("New instance created");
        }
        else {
            System.out.println("Instance already created.Returning previously created instance.....");
        }
        return instance;
    }

    public int getLateFees(){
        return lateFees;
    }

    public void setLateFees(int lateFees){
        this.lateFees = lateFees;
    }

    public int getBorrowingLimit(){
        return borrowingLimit;
    }

    public void setBorrowingLimit(int borrowingLimit){
        this.borrowingLimit = borrowingLimit;
    }
}
