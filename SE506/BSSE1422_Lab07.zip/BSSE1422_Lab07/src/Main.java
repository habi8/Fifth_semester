//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

       LibraryConfigManager configManager = LibraryConfigManager.getInstance();

        System.out.println("Late fees: " + configManager.getLateFees());
        System.out.println("Borrowing limit: "+ configManager.getBorrowingLimit() );

        User user = new User("Rahim",4, true);
        LibraryAccess access = new LibraryAccessProxy();
        access.accessItems("007",user);
        System.out.println(user.getBorrowedItems());

        LibraryItems book = LibraryItemFactory.createLibraryItem("Book","Bangla grammar-Hayat mahmud");
        LibraryItems magazine = LibraryItemFactory.createLibraryItem("magazine","Plane");

        System.out.println(book.getDetails());
        book.borrowItems();

        System.out.println(magazine.getDetails());
        magazine.borrowItems();


    }
}