public class Magazine implements LibraryItems{
    private String title;

    public Magazine(String title){
        this.title = title;
    }

    @Override
    public String getDetails(){
        return "magazine "+ title;
    }

    @Override
    public void borrowItems(){
        System.out.println("You have borrowed the magazine: "+ title);
    }
}
