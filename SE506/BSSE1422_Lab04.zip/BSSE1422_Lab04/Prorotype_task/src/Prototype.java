import java.util.HashMap;

public interface Prototype {
    public Prototype clone();

    HashMap<Prototype,Prototype> productRegistry = new HashMap<>();
    public void insert(Prototype p);
}
