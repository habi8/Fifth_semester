//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Tshirt originalTshirt = new Tshirt("Polo T","Clothing",20,"Yellow","XL");
        PC originalPC = new PC("Desktop","Electronics",500,"1TB","5000 mAh");

        Tshirt clonedTshirt = (Tshirt)originalTshirt.clone();
        clonedTshirt.insert(clonedTshirt);
        clonedTshirt.getType();

        PC clonedPC = (PC)originalPC.clone();
        clonedPC.insert(clonedPC);
        clonedPC.getType();
    }
}