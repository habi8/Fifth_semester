public class PC extends Product{
    private String storage;
    private String battery;

    public PC(String name,String category,int price,String storage,String battery){
        super(name,category,price);
        this.storage = storage;
        this.battery = battery;
    }

    public String getStorage(){
        return storage;
    }

    public void setStorage(String storage){
        this.storage = storage;
    }

    public void setBattery(String battery){
        this.battery = battery;
    }

    public String getBattery(){
        return Battery;
    }
    @Override
    public void getType(){
        System.out.println("I'm a "+ getName());
    }

    @Override
    public void insert(Prototype p){
        productDirectory.add(p);
    }

    @Override
    public Prototype clone(){
        return new Tshirt(this.getName(),this.getCategory(),this.getPrice(),this.getStorage(),this.getBattery());
    }


}
