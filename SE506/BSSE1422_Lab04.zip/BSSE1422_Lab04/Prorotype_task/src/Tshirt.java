public class Tshirt extends Product{
    private String color;
    private String size;

    public Tshirt(String name,String category,int price,String color,String size){
        super(name,category,price);
        this.color = color;
        this.size = size;
    }

    public String getColor(){
        return color;
    }

    public void setColor(String color){
        this.color = color;
    }

    public void setSize(String size){
        this.size = size;
    }

    public String getSize(){
        return size;
    }
    @Override
    public void getType(){
        System.out.println("I'm a "+ getName());
    }

    @Override
    public void insert(Prototype p){
        productDirectory.add(p);
    }

    @Override
    public Prototype clone(){
        return new Tshirt(this.getName(),this.getCategory(),this.getPrice(),this.getColor(),this.getSize());
    }



}
