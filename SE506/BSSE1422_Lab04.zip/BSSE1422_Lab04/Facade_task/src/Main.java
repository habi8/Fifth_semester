//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        AccountChecker acc = new AccountChecker("12345678");
        PinChecker pin = new PinChecker(123456);
        BalanceChecker bal = new BalanceChecker(34);

        DeliverySystem ds = new DeliverySystem(acc,pin,bal);
        ds.order();
    }
}