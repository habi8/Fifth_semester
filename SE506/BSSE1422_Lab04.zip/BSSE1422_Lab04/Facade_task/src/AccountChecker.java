public class AccountChecker {
    String accountNumber;
    public AccountChecker(String accountNumber){
        this.accountNumber = accountNumber;
    }
    public String checkAccount(){
        return accountNumber;
    }

}
