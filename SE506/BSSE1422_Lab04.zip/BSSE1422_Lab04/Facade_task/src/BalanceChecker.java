public class BalanceChecker {
    int balance;
    public  BalanceChecker(int balance){
        this.balance = balance;
    }
    public int checkBalance() {
        return balance;
    }

}
