public class PinChecker {
    int pin;
    public PinChecker(int pin){
        this.pin = pin;
    }
    public int checkPin(){
        return pin;
    }
}
