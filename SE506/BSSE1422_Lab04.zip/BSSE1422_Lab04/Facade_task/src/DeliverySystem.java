public class DeliverySystem {
    AccountChecker acc;
    PinChecker pin;
    BalanceChecker bal;

    public DeliverySystem(AccountChecker acc,PinChecker pin, BalanceChecker bal){
        this.acc = acc;
        this.pin = pin;
        this.bal = bal;
    }

    public void order(){

        if(acc.checkAccount().equals("12345678") && pin.checkPin()==123456 && bal.checkBalance()>20){
          System.out.println("Pizza ordered");
        }

        else System.out.println("Info mismatched");
    }

}
