public class LegacyPrinter {
    public void Legacyprint(String document){
        System.out.println("Printing Legacy document: "+document);
    }
}
