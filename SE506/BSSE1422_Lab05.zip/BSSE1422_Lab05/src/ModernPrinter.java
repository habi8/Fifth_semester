public class ModernPrinter implements Printer{
    @Override
    public void print(String document){
        System.out.println("Printing modern document : "+document);
    }
}
