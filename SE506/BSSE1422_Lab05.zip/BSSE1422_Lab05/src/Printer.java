public interface Printer {
    public abstract void print(String document);
}
