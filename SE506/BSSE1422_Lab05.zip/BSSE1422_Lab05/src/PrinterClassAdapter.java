public class PrinterClassAdapter extends LegacyPrinter implements Printer{

    @Override
    public void print(String document){
        Legacyprint(document);
    }

}
