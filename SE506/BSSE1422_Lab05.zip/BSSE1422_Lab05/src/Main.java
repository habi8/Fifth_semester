//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        ModernPrinter modernPrinter = new ModernPrinter();
        modernPrinter.print("Some random documents");

        LegacyPrinter legacyPrinter = new LegacyPrinter();
        Printer printerAdapter = new PrinterAdapter(legacyPrinter);
        printerAdapter.print("Some more documents");

        Printer printerClassAdapter = new PrinterClassAdapter();
        printerClassAdapter.print("Homework");
    }
}